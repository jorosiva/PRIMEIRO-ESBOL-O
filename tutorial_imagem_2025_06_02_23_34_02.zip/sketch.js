var limg = 750/2;
var himg = 460/2;
var ximg = 10;
var yimg = 20;
var img;

function preload(){
img=loadImage("paisagem.jpg");
}

function setup() {
  createCanvas(800,500);
} 

function draw() { 
  background(220); 
  
  
  image(img,ximg,yimg,limg,himg); 
} 